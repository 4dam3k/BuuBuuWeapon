assault. Green: Weapons hot. Light blue: Stealth.

GameSetup.oldUpdate = GameSetup.oldUpdate or GameSetup.update
PlayerManager.xpTexts = {}

function round2(num, idp)
  return string.format("%." .. (idp or 0) .. "f", num)
end

function GameSetup:update(t, dt)
	GameSetup.oldUpdate(self, t, dt)
	
	
	if PlayerManager.posPanel then
		local text = ""
		if managers.groupai and managers.groupai:state() then 
			text = round2(managers.groupai:state()._difficulty_value or 0,2)
			PlayerManager.posText:set_color(managers.groupai:state()._hunt_mode and Color(1,0,0) or managers.groupai:state()._enemy_weapons_hot and Color(0,1,0) or Color(0,1,1))
		else
			text = round2(0,2)
			PlayerManager.posText:set_color(Color(0,1,1))
		end
		if managers.experience and managers.experience._global and managers.experience._global.mission_xp_current then
			text = text .. " " .. tostring(Application:digest_value(managers.experience._global.mission_xp_current, false)) or "None"
			
			for xpTime, xpText in pairs(PlayerManager.xpTexts) do
				if t < xpTime + 20 then
					text = text .. ", " .. xpText
				else
					table.remove(PlayerManager.xpTexts, xpTime)
				end
			end
		else
			text = text .. " 0"
		end
		PlayerManager.posText:set_text(text)
	else
		if managers.hud then
			local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
			PlayerManager.posPanel = hud.panel:panel({name = "positionpanel"})
			PlayerManager.posText = PlayerManager.posPanel:text({
				name = "textname",
				text = "texttext",
				font = tweak_data.hud.medium_font,
				font_size = tweak_data.hud.name_label_font_size,
				color = Color.green,
				align = "left",
				vertical = "top",
				layer = 1,
				w = 2000,
				h = 24
			})
		end
	end
end


core:import("CoreMissionScriptElement")

function ElementExperience:on_executed(instigator)
	if not self._values.enabled then
		return
	end
	
	local text = self._editor_name .. ": " .. self._values.amount
	local curTime = TimerManager:game():time()
	
	if PlayerManager.xpTexts[curTime] then 
		PlayerManager.xpTexts[curTime] = PlayerManager.xpTexts[curTime] .. ", " .. text
	else
		PlayerManager.xpTexts[curTime] = text
	end
	
	log("exp " .. text .. " " .. tostring(curTime))
	
	managers.experience:mission_xp_award(self._values.amount)
	ElementExperience.super.on_executed(self, instigator)
end