local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)

self.saw_secondary.stats.concealment = 30
self.deagle.stats.concealment = 30
self.ksg.stats.concealment = 31

end